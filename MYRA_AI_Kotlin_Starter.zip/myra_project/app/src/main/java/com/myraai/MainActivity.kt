package com.myraai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import android.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var keyBox: EditText
    private val prefs by lazy { getSharedPreferences("myra", MODE_PRIVATE) }
    private val http = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val askPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val words = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) { input.setText(words); askMyra(words) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        root.addView(TextView(this).apply { text = "✦ MYRA AI ✦\nYour personal Android assistant"; textSize = 24f })
        keyBox = EditText(this).apply { hint = "Gemini API key (stored only on this phone)"; setText(prefs.getString("api_key", "")); inputType =  textPassword() }
        root.addView(keyBox)
        root.addView(Button(this).apply { text = "Save API Key"; setOnClickListener { prefs.edit().putString("api_key", keyBox.text.toString().trim()).apply(); toast("API key saved on device") } })
        output = TextView(this).apply { text = "Namaste! Main MYRA hoon. Aap mujhse pooch sakte hain."; textSize = 17f; setPadding(0,24,0,24) }
        root.addView(output)
        input = EditText(this).apply { hint = "MYRA ko message likho…" }
        root.addView(input)
        root.addView(Button(this).apply { text = "Send to MYRA"; setOnClickListener { askMyra(input.text.toString()) } })
        root.addView(Button(this).apply { text = "🎙 Speak"; setOnClickListener { startSpeech() } })
        root.addView(Button(this).apply { text = "Enable Screen Control"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "Start MYRA background session"; setOnClickListener { ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, MyraForegroundService::class.java)) } })
        root.addView(Button(this).apply { text = "Stop background session"; setOnClickListener { stopService(Intent(this@MainActivity, MyraForegroundService::class.java)) } })
        root.addView(Button(this).apply { text = "Memory (local notes)"; setOnClickListener { memoryDialog() } })
        setContentView(ScrollView(this).apply { addView(root) })
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) askPermission.launch(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) askPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun textPassword() = 0x00000081
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun startSpeech() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"); putExtra(RecognizerIntent.EXTRA_PROMPT, "MYRA se boliye")
        }
        try { speechLauncher.launch(i) } catch (_: Exception) { toast("Speech recognition available nahi hai") }
    }
    private fun askMyra(question: String) {
        if (question.isBlank()) return
        output.text = "MYRA soch rahi hai…"
        val apiKey = prefs.getString("api_key", "").orEmpty()
        if (apiKey.isBlank()) { output.text = "Pehle Gemini API key save karein."; return }
        scope.launch {
            val answer = withContext(Dispatchers.IO) {
                try {
                    val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", question)))))
                    val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
                        .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                    http.newCall(req).execute().use { r ->
                        val raw = r.body?.string().orEmpty()
                        if (!r.isSuccessful) "API error ${r.code}: ${raw.take(300)}" else JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                    }
                } catch (e: Exception) { "Network error: ${e.localizedMessage}" }
            }
            output.text = answer
            if (::tts.isInitialized) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "myra_reply")
            saveConversation(question, answer)
        }
    }
    private fun saveConversation(q: String, a: String) {
        val old = prefs.getString("history", "").orEmpty()
        prefs.edit().putString("history", (old + "\nYou: $q\nMYRA: $a\n").takeLast(12000)).apply()
    }
    private fun memoryDialog() {
        val box = EditText(this).apply { hint = "MYRA ki local memory / note"; setText(prefs.getString("memory", "")) }
        AlertDialog.Builder(this).setTitle("MYRA Memory").setView(box).setPositiveButton("Save") { _, _ -> prefs.edit().putString("memory", box.text.toString()).apply(); toast("Memory saved") }.setNegativeButton("Cancel", null).show()
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN") }
    override fun onDestroy() { scope.cancel(); if (::tts.isInitialized) tts.shutdown(); super.onDestroy() }
}
