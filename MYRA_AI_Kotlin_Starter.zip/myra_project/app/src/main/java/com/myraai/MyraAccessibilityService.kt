package com.myraai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Handler
import android.os.Looper

/** Screen actions run only after the user manually enables MYRA in Android Accessibility settings. */
class MyraAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }
    override fun onServiceConnected() { instance = this }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build()
        return dispatchGesture(g, null, Handler(Looper.getMainLooper()))
    }
    fun clickText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label)
        for (node in nodes) {
            var n: AccessibilityNodeInfo? = node
            while (n != null) { if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK); n = n.parent }
        node.recycle()
        return false
    }
    fun scrollDown(): Boolean = rootInActiveWindow?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    companion object { @Volatile var instance: MyraAccessibilityService? = null }
}
