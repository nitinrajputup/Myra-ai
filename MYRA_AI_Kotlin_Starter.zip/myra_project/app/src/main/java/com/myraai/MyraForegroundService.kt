package com.myraai

import android.app.* 
import android.content.Intent
import android.os.Build
import android.os.IBinder

class MyraForegroundService : Service() {
    override fun onCreate() { super.onCreate(); createChannel() }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("myra_assistant", "MYRA Assistant", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = Notification.Builder(this, "myra_assistant")
            .setContentTitle("MYRA AI active").setContentText("Background assistant session is running")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        startForeground(41, notification)
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
