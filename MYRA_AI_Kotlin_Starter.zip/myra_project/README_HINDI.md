# MYRA AI Android starter (Kotlin)

यह एक **starter project** है, वीडियो में बताए गए हर फीचर का पूर्ण implementation नहीं। इसमें Gemini text chat, Hindi speech recognition/TTS, local notes/history, Accessibility Service skeleton और foreground notification session है।

## Build
1. ZIP को Android Studio वाले PC पर extract करें (फोन पर AndroidIDE/Gradle compatible environment भी इस्तेमाल कर सकते हैं)।
2. `MYRA_AI` folder खोलें और Gradle sync होने दें। JDK 17 और Android SDK Platform 35 आवश्यक हैं।
3. Build > Build APK(s)।

## Gemini
ऐप खोलकर Gemini API key डालें और Save API Key करें। Key केवल इस डिवाइस के SharedPreferences में रखी है; production में Android Keystore/backend proxy अपनाएँ।

## Screen control
Enable Screen Control दबाएँ → Android Accessibility Settings → MYRA AI enable करें। यह सेवा user-enabled होने के बाद ही gestures/accessibility actions कर सकती है। अभी sample में tap coordinates, text click, scroll और Back helper हैं; chat command से arbitrary click automation जोड़ना बाकी है।

## अभी पूर्ण रूप से शामिल नहीं
- Always-on wake word (Android background microphone restrictions)
- Camera live stream / image upload (permission मौजूद, implementation बाकी)
- Notification listener (अलग user-granted Notification Access service चाहिए)
- Floating overlay (SYSTEM_ALERT_WINDOW consent चाहिए)
- WhatsApp/Call/Settings automation (Android permissions, intents, confirmation और policy limits)
- Deep research, multi-agent orchestration, PC connector, mission scheduler
- Encrypted robust memory, app database, complete tool planner

Security: ऐप को Accessibility permission देने से वह स्क्रीन की सामग्री पढ़/क्लिक कर सकता है। केवल अपने trusted build को अनुमति दें। API key किसी के साथ साझा न करें।
